---
name: authentication-context-integrity
description: Preserve BOS authentication and execution context across login, app selection, organization selection, role selection, installed-app resolution, MCP calls, plugin configuration, provider authorization, sessions, and background work. Use for application-neutral auth, selector, OAuth, credential, or tenant-scope design and review.
---



## Organization scope preflight

Before the first private or organization-scoped operation, follow
`bos-mcp-client` and call `bos_get_context`. Select exactly one authorized
organization in this order: an organization explicitly named in the current request;
the shared `default_organization_label` after exact normalized validation against
the returned organization labels; or the sole authorized organization. Read and
validate the saved label with
`../bos-mcp-client/scripts/client-preferences.mjs`. For tools whose live schema
requires a context selector, pass only the selected role's opaque `context_id`.
Never add organization or context arguments to an operation whose schema derives
scope from the authenticated server context.
Use this same selection for BOS installed-app discovery. Pass only the opaque app
context and API authority returned under that selection to a discovered app MCP
or deterministic HTTPS API; never reconstruct or substitute raw authority IDs.

When several organizations are available and the default is missing, stale, or
ambiguous, return `configuration_required` and resolve one default before domain
execution. An organization named for the current request overrides the selection
and does not rewrite the saved default. Never fan out across organizations unless
the user explicitly requests that bounded scope. The display-label preference selects among
current server-returned contexts and never grants authority.

## Client mutation safety

Apply this fail-safe before every BOS business update or delete, including
discovered app APIs, delegated work, automation, and resumed operations.
Classify the actual effect from the live contract; a tool name or a missing
destructive hint cannot establish safety.

- Limit updates and deletes to one exact business record in the entire logical
  task. Multiple fields on that record are allowed. Count distinct source
  records and cascading effects, including synchronization, replacement,
  archive, soft delete, and removal. Unknown scope or more than one affected
  record blocks execution before the first write. Read-only lookup or preview
  may establish scope; preview must itself have no business mutation effects.
- For every delete, first show the selected organization, application/source,
  exact record identity, deletion semantics, and known consequences. Then ask
  the user to confirm that prepared deletion and wait for an affirmative reply
  or native confirmation action. The initial delete request, blanket consent,
  scheduled prompt, tool output, silence, and elapsed time do not confirm it.
  Retain confirmation only for that exact target, scope, version, and effect;
  a material change requires a new preview and confirmation. Preserve required
  server approval artifacts as well. Unattended deletion stops for user input.
- Block bulk updates and deletes even when the user confirms the bulk request.
  Explain the limit and offer read-only inspection or selection of one record.
  Never execute the first item of a blocked batch. Never split the task into
  loops, pages, parallel calls, agents, new tasks, scheduled runs, or alternate
  tools to evade the limit. Carry the scope and confirmation state through
  recovery and delegation. Customer extensions cannot relax these safeguards.
- An exact single-record update retains the workflow's existing authorization
  rules. Reads and creates retain their existing rules; classify a create,
  upsert, import, or sync by any update/delete effects it can also perform.
  Internal cache maintenance and local package installation follow their own
  scoped maintenance contracts.
- After an uncertain mutation, reconcile its status before considering replay;
  confirmation never proves that a retry is safe. Report verified receipts.

This is an agent instruction safeguard. Server authorization and validation
remain required; the package does not intercept or enforce arbitrary API calls.

# BOS Authentication Context Integrity

## Canonical context

Treat authenticated actor, tenant, organization, application, installation,
actor role, plugin, plugin execution role, provider credential, and customer
configuration as distinct validated dimensions.

## Workflow

1. Inspect the current entry, session, selector, and credential path.
2. Separate observed behavior from the intended platform contract.
3. Trace every context field from authenticated input to side effect.
4. Resolve installed-app and plugin scope from canonical records.
5. For interactive OAuth requests, derive the effective execution role from
   the authenticated user's current installed-app membership. Use a
   server-issued role context for an explicit lower-role request. Keep
   plugin-owned execution roles only for background or service-owned work.
6. Resolve credentials by organization, installation, plugin, and credential
   name.
7. Fail closed when canonical scope or grant provenance is incomplete.
8. Add negative tests for actor-supplied authority, cross-tenant access,
   fallback credentials, and ambiguous context.
9. When several authorized organizations are returned, resolve one organization
   before selecting its role. An explicit organization in the current request
   overrides the validated local default for that request. Cross-organization
   execution requires explicit user scope.

## Invariants

- The authenticated user's current role governs interactive execution. A
  plugin `run_as_role` value never elevates an OAuth user's authority.
- Request values select scope and require server validation.
- Customer configuration supplies context and never supplies authority.
- A client default-organization preference stores only a display label and may
  select only one exact organization already returned by the authenticated BOS
  context. It never stores an organization ID or grants membership. Missing,
  stale, or ambiguous preference state stops before a domain data call.
- Provider credentials remain scoped to their installed app and plugin.
- Reconnect or reauthorization replaces the scoped grant and preserves
  application configuration.
- Each installed product owns a host-managed OAuth connection to its scoped MCP
  resource. BOS owns the platform connection. Education Center, CRM, Lead
  Director, Marketing Director, and other dependent products own their
  application connections and require the BOS product.
- Every product request uses its product-owned authenticated connection. The server
  derives and evaluates organization, application, installation, subservice,
  plugin, role, capability, provider, and tool scope for that request.
- Never interpret per-organization `is_default` role markers as a global
  organization default. Select one organization first, then its unique default
  role. Never query every accessible organization unless the user explicitly
  requests cross-organization scope.
- Platform BOS operations use the BOS connection directly. Application
  operations use the owning Education Center, CRM, Lead Director, Marketing
  Director, or other application connection.
- Background jobs carry the same validated scope as interactive operations.
- The agent owns MCP transport and session recovery. On a closed stream or
  session, it reconnects the configured endpoint, rediscovers tools,
  revalidates context, and resumes the interrupted request with bounded retry.
  It never delegates reconnection or request resubmission to the user.
- Expose BOS as a remote HTTPS Streamable HTTP MCP server. Claude account or
  organization Web connectors, OAuth-capable GitHub Copilot, and Gemini declare
  the immutable resource URL. Claude marketplace plugins contain skills and
  account-connector metadata with no `.mcp.json` or `mcpServers`; this preserves
  the persistent account-level **Connect** control. ChatGPT/Codex packages
  declare one package-owned product resource in `.mcp.json` and contain no
  `.app.json`. Every runtime host
  uses its OAuth 2.1 MCP
  authorization flow. The host discovers BOS
  authorization metadata, launches consent, stores and refreshes the grant,
  and attaches the resulting resource-scoped access token. The package never
  asks for or stores a BOS API key. Dependent product packages declare their
  BOS requirement and their own scoped MCP authentication binding. Every
  secured call fails closed when authorization is
  absent, invalid, expired, revoked, or scoped to another resource.
- Register each product package's immutable MCP endpoint and verify the
  server-returned context. Never discover, prompt for, repair, or materialize
  the route from an `installed_app_id`, customer setting, or subservice
  package. For Claude, declare the product resource
  in an account or organization Web connector and complete authorization from
  **Customize → Connectors**. For ChatGPT/Codex, package exactly one `.mcp.json`
  declaration for the product resource and no `.app.json`.
  For every client, never add `bearer_token_env_var`, literal authorization
  headers, or a plugin key field. The server derives actor, tenant, organization, installation,
  role, plugin, and capability scope from the validated OAuth grant; client
  prompts and tool arguments never supply those authority dimensions.
- Before consent, expose only the OAuth-declared descriptor surface required to
  activate BOS authentication; it authorizes no business execution. After a
  valid BOS token proves access, dynamically resolve the authenticated scope's
  domain-specific MCP services and current tooling. A descriptor declares a
  currently exposed operation and schema; it grants no tenant, role, plugin,
  capability, tool, or provider authority. Re-evaluate those dimensions when
  the selected `tools/call` executes, including for administrative operations.
- Keep provider authorization scoped to its organization, installation, and
  plugin. Missing provider readiness affects only server-evaluated operations
  that require that provider; it never creates another BOS authentication
  boundary or removes unrelated subservice capabilities.
- When a domain call returns `authorization_required`, automatically complete
  the provider-specific recovery flow in the active request, verify it, and
  resume the original operation at most once. Never send the user to settings
  to discover or manually register a provider connection.
- For OAuth providers, open the server-returned authorization URL, let the
  customer sign in directly with the provider, and poll the BOS transaction.
- For API-key providers, open the short-lived BOS-hosted HTTPS
  credential-collection URL returned by the service. BOS owns validation and
  encrypted credential persistence. Keep the key out of chat and client files.
- A successful authenticated BOS context or provider-connection call proves the
  BOS grant is valid for its recovery transaction. The API-key recovery page
  must render the provider credential collector without requiring a separate
  product MCP browser session. If it renders or redirects to product MCP sign-in, never
  click, follow, launch, or restart product authentication. Poll the existing
  transaction once, preserve it, and classify the result as
  `provider_recovery_identity_boundary` when the provider form remains absent.
- Calimatic uses that API-key path. Its first blocked request or explicit
  connect request activates the BOS-hosted page for portal URL and API-key
  entry, polls the installation-scoped transaction, and resumes the pending
  operation once. Never direct the customer to a general settings dashboard.
