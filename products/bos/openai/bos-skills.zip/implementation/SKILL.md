---
name: implementation
description: Implement application-neutral Business Operating System platform changes while preserving tenant isolation, explicit app scope, PO/GO data boundaries, server-owned runtime behavior, and fail-closed execution. Use for shared BOS runtime, MCP, plugin, authentication-context, provider, migration, or cross-application infrastructure changes.
---



## Organization scope preflight

Before the first private or organization-scoped operation, follow
`bos-mcp-client` and call `bos_get_context`. Select exactly one authorized
organization in this order: an organization explicitly named in the current request;
the shared `default_organization_label` after exact normalized validation against
the returned organization labels; or the sole authorized organization. Read and
validate the saved label with
`../bos-mcp-client/scripts/client-preferences.mjs`. For tools whose live schema
requires a context selector, pass only the selected role's opaque `context_id`.
Never add organization or context arguments to an operation whose schema derives
scope from the authenticated server context.
Use this same selection for BOS installed-app discovery. Pass only the opaque app
context and API authority returned under that selection to a discovered app MCP
or deterministic HTTPS API; never reconstruct or substitute raw authority IDs.

When several organizations are available and the default is missing, stale, or
ambiguous, return `configuration_required` and resolve one default before domain
execution. An organization named for the current request overrides the selection
and does not rewrite the saved default. Never fan out across organizations unless
the user explicitly requests that bounded scope. The display-label preference selects among
current server-returned contexts and never grants authority.

## Client mutation safety

Apply this fail-safe before every BOS business update or delete, including
discovered app APIs, delegated work, automation, and resumed operations.
Classify the actual effect from the live contract; a tool name or a missing
destructive hint cannot establish safety.

- Limit updates and deletes to one exact business record in the entire logical
  task. Multiple fields on that record are allowed. Count distinct source
  records and cascading effects, including synchronization, replacement,
  archive, soft delete, and removal. Unknown scope or more than one affected
  record blocks execution before the first write. Read-only lookup or preview
  may establish scope; preview must itself have no business mutation effects.
- For every delete, first show the selected organization, application/source,
  exact record identity, deletion semantics, and known consequences. Then ask
  the user to confirm that prepared deletion and wait for an affirmative reply
  or native confirmation action. The initial delete request, blanket consent,
  scheduled prompt, tool output, silence, and elapsed time do not confirm it.
  Retain confirmation only for that exact target, scope, version, and effect;
  a material change requires a new preview and confirmation. Preserve required
  server approval artifacts as well. Unattended deletion stops for user input.
- Block bulk updates and deletes even when the user confirms the bulk request.
  Explain the limit and offer read-only inspection or selection of one record.
  Never execute the first item of a blocked batch. Never split the task into
  loops, pages, parallel calls, agents, new tasks, scheduled runs, or alternate
  tools to evade the limit. Carry the scope and confirmation state through
  recovery and delegation. Customer extensions cannot relax these safeguards.
- An exact single-record update retains the workflow's existing authorization
  rules. Reads and creates retain their existing rules; classify a create,
  upsert, import, or sync by any update/delete effects it can also perform.
  Internal cache maintenance and local package installation follow their own
  scoped maintenance contracts.
- After an uncertain mutation, reconcile its status before considering replay;
  confirmation never proves that a retry is safe. Report verified receipts.

This is an agent instruction safeguard. Server authorization and validation
remain required; the package does not intercept or enforce arbitrary API calls.

# BOS Implementation

## Repository ownership boundary

When this skill runs from BOS Operations Center, implement only package-owned
surfaces: canonical skills and documentation, product and plugin manifests,
client generators and generated packages, release metadata, and package tests.

Never enter or mutate a BOS server repository from an Operations Center task.
Do not create a sibling server worktree, edit backend routes, commit or push a
server branch, open or merge a server pull request, operate Cloud Run or GCP,
change a server database, or deploy server code.

If the requested behavior requires server implementation, preserve the package
finding and return a paste-ready prompt for an agent running in the owning
server repository. Give that agent the sanitized evidence, required invariant,
relevant protocol contract, deployment scope, and observable post-deployment
verification. For changes affecting the BOS MCP authentication or discovery
contract, make the client-owned Operations Center acceptance suite part of
the server change's acceptance criteria: `npm run contract:check`, `npm run
contract:oauth-discovery-live -- --resource-url "$BOS_MCP_RESOURCE_URL"
--format json`, `npm run contract:oauth-tool-auth-live -- --resource-url
"$BOS_MCP_RESOURCE_URL" --tool bos_get_context --format json`, and `npm run
contract:oauth-live -- --authorize-url
"$BOS_OAUTH_AUTHORIZE_URL" --format json`. The server-side agent independently
determines the implementation and release path. Return exactly one continuous
Markdown prompt as the entire server handoff response. Keep all protocol
requirements, client-owned commands, and acceptance criteria in that single
copyable prompt.

## Server handoff scope

Write the prompt around the user's requested server outcome. Treat attached
client specifications and prior conversations as evidence; extract the relevant
server requirements instead of forwarding their instructions wholesale.
Include only the affected server behavior, API or data contract, necessary graph
wiring, existing-data migration, deployment scope, and observable acceptance
criteria that the request requires. Retain client evidence only when it explains
a server defect or a required response the server must provide.

Omit unrelated client installation, package layout, UI rendering, local cache,
and agent recovery procedures. Preserve existing authentication, authorization,
and provider recovery behavior unless the user requests a change or observed
evidence establishes a necessary dependency; identify that dependency explicitly.
A graph or profile-data change alone does not imply an authentication change.

Choose validation for the touched server surface. Include the OAuth acceptance
suite above only when its stated condition applies, and label those commands as
running from BOS Operations Center against the deployed candidate. Keep client
execution with its owner; request the server endpoint and deployment evidence
needed for that verification. For other server work, use the owning repository's
focused tests and relevant post-deployment checks. Before returning the prompt,
remove each detail that does not help the server agent implement or verify the
requested outcome.

## Workflow

1. Read the controlling architecture and locate the owning platform component.
2. Reproduce the requirement or failure with the narrowest deterministic check.
3. Identify the native BOS primitive and existing implementation pattern.
4. Add or update a focused test that captures the required invariant.
5. Implement the smallest application-neutral change.
6. Keep routers, PO orchestration, GO persistence, providers, and clients within
   their documented responsibilities.
7. Update shared documentation or skill guidance when the change establishes a
   durable platform rule.
8. Run focused tests, boundary contracts, security checks, and packaging checks.
9. Review the actual diff against the architecture before handoff.

## Required boundaries

- Back every required file, marker, manifest field, boundary, and release
  precondition with an automated test that exercises the real repository
  shape. Fixture-only tests may supplement this coverage; they never replace
  verification of required canonical files.
- Implement every current product from its present contract and observable
  user journey. Never defer a required connection, capability, or workflow to
  an assumed future product, future package composition, or anticipated growth.
- BOS owns its platform MCP connection. Each dependent product owns one scoped
  MCP connection, declares BOS as a required product dependency, and packages
  only its relevant skills. The server evaluates product,
  installation, plugin, role, capability, and provider scope for every request.
- Align transport ownership with product capability ownership. Route platform
  BOS operations through BOS and route application operations through the
  Education Center, CRM, Lead Director, Marketing Director, or other owning
  product MCP.
- Derive authority from authenticated context and canonical installed-app
  records.
- Treat request identifiers as selectors that require authorization.
- Keep secrets in managed credential storage.
- Keep provider side effects inside explicit tenant and installation scope.
- Preserve idempotency for mutations and migrations.
- Keep application-specific paths, terminology, tests, and release gates in
  application specialization skills.

Treat a passing implementation with an undeclared product dependency or a
missing product-owned MCP as incomplete. Record the missing current capability
explicitly and block release until its present owner implements it.

Report changed files, validation results, migration effects, and remaining
risks. Require independent architecture review when the owning repository
defines one.
