---
name: email-account-routing
description: Route email searches, thread reads, summaries, drafts, sends, and mailbox actions through the exact mailbox owner and tenant. Use whenever a BOS workflow names or implies email, Gmail, a mailbox, a message, or a thread.
---



## Scoped authorization preflight
For an explicit BOS sign-out request, first follow `bos-mcp-client`'s
current-connection sign-out branch. Invoke only discovered `bos_logout`
with empty arguments and terminate after its receipt or canonical challenged
401. This connection-level action precedes context/default selection and
authentication recovery; do not sign in to perform logout.


First apply the versioned identity-context workflow in `bos-mcp-client`.
For live `bos-identity-mcp/v2`, resolve explicit request scope or the saved
customer default against fresh authorized contexts, discover tools for the
selected handle, and execute with that same handle. This branch governs
context selection throughout this skill, including older scoped-grant wording.
A missing operation never permits changing organization or role to find it.
The following single-context rules apply only to legacy scoped-grant discovery.

Before the first private or organization-scoped operation, follow
`bos-mcp-client` and call `bos_get_context` to validate the exact scoped OAuth
connection. The server-owned grant fixes organization, application, installation,
and role authority. Never add `org_id`, `app_code`, `installed_app_id`,
`delegated_role_id`, `context_id`, or another authority selector to a business
operation. Invoke only the operation's live-declared business arguments.
Use the same scoped connection for BOS installed-app discovery. Preserve the
server-advertised MCP contact and deterministic HTTPS API contract without
reconstructing or substituting raw authority identifiers.

An operation that requires a different organization, application, installation,
or role requires the BOS-owned scoped authorization flow. The client never changes
authority by adding request arguments.

## Client mutation safety

Apply this fail-safe before every BOS business update or delete, including
discovered app APIs, delegated work, automation, and resumed operations.
Classify the actual effect from the live contract; a tool name or a missing
destructive hint cannot establish safety.

- Limit updates and deletes to one exact conceptual business record in the
  entire logical task. Multiple fields on that record are allowed. That record
  may resolve to one through five explicit source-record targets in one
  discovered service request. Count distinct conceptual records and cascading
  effects, including synchronization, replacement, archive, soft delete, and
  removal. Unknown scope, more than five source targets, or more than one
  conceptual record blocks execution before the first write. Read-only lookup
  or preview may establish scope; preview must itself have no business mutation
  effects.
- For every delete, first show the selected organization, application/source,
  exact record identity, deletion semantics, and known consequences. Then ask
  the user to confirm that prepared deletion and wait for an affirmative reply
  or native confirmation action. The initial delete request, blanket consent,
  scheduled prompt, tool output, silence, and elapsed time do not confirm it.
  Retain confirmation only for that exact target, scope, version, and effect;
  a material change requires a new preview and confirmation. Preserve required
  server approval artifacts as well. Unattended deletion stops for user input.
- Block bulk updates and deletes even when the user confirms the bulk request.
  Explain the limit and offer read-only inspection or selection of one record.
  Never execute the first item of a blocked batch. Never split the task into
  loops, pages, parallel calls, agents, new tasks, scheduled runs, or alternate
  tools to evade the limit. Carry the scope and confirmation state through
  recovery and delegation. Customer extensions cannot relax these safeguards.
- An exact one-conceptual-record update retains the workflow's existing
  authorization rules. Reads and creates retain their existing rules; classify
  a create, upsert, import, or sync by any update/delete effects it can also
  perform. Internal cache maintenance and local package installation follow
  their own scoped maintenance contracts.
- After an uncertain mutation, invoke only the exact service-returned bodyless
  state action and service-declared timing. Never replay the mutation or
  construct a status route, selector, retry schedule, or reconciliation
  request. Confirmation never proves that another mutation is safe. Report
  verified receipts.

This is an agent instruction safeguard. Server authorization and validation
remain required; the package does not intercept or enforce arbitrary API calls.

# Email Account Routing

Resolve the requested mailbox before selecting a connector. Mailbox ownership,
authenticated identity, tenant scope, and mutation authority control the route;
business purpose alone never does.

## Routing workflow

1. Read the active product settings and call `bos_get_context` when BOS scope is
   needed. Treat configured mailbox routes as data, never as packaged defaults.
2. If the user explicitly names a separately connected mailbox, use that
   connector only after its authenticated identity matches the request.
3. Route every BOS-managed mailbox through the active product connection whose
   scoped grant owns its provider credential.
4. Keep source and destination mailboxes independent in cross-business work.
   Retrieve through the source owner and draft, send, archive, label, or mutate
   through the destination owner.
5. Stop when identity, tenant, provider readiness, or mailbox ownership cannot
   be verified. Report the requested mailbox and the missing readiness state.

## Message content and attachments

1. Search the authorized mailbox and read the exact thread before selecting
   message content. Use the returned thread, message, and attachment references;
   never construct or alter provider identifiers.
2. Answer from the message body when the requested information is already in
   the thread. When the person needs a file, image, document, or other attached
   content, discover the current context's callable BOS tool whose live
   descriptor identifies Gmail attachment download, declares a resource effect,
   and returns a native embedded resource. Require its advertised input schema
   to accept the exact `thread_id`, `message_id`, and `attachment_id` from that
   thread. For identity-v2, use `bos_list_context_tools` with the fresh selected
   context and `bos_execute` with the exact returned tool name and those three
   arguments; for a legacy directly callable tool, invoke its advertised name
   and schema. Context-specific tool names are discovery results, not static
   client configuration.
3. If several attachments could satisfy the request, identify them by
   provider-derived filename and MIME type and ask the person to select one.
   Continue directly when the request identifies exactly one attachment.
4. Present that returned embedded resource as the downloadable result. Preserve
   its server-derived filename and MIME type, and report its byte size and
   SHA-256 digest when verification helps. The separate discovered HTTPS
   attachment-read operation returns raw binary bytes; use it only when the
   host has a verified native file-delivery action for those bytes. Never claim
   raw bytes alone are an embedded downloadable resource.
5. Treat attachment bytes as ephemeral response content. Never copy them into
   BOS persistence, logs, caches, prompts, or a signed URL. Respect the
   operation's published size limit and typed failure.
6. For a link to a separately authorized Drive file or another provider
   resource, use that provider's discovered read operation after the person
   requests the linked resource.

Use the BOS mailbox operation directly. A browser session or separate browser
sign-in is outside this routing path.

Never infer another direct mailbox from browser state, an email domain, a local
credential, or a connector used by a different tenant. Read-only searches may
proceed when authorized. Sending, deleting, archiving, labeling, or changing
mailbox state requires clear user intent and the owning route.
