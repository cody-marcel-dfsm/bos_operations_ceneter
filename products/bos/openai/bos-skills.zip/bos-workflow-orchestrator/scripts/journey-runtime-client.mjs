#!/usr/bin/env node

import Ajv2020 from "./vendor/ajv2020.bundle.mjs";
import {validateSafeBosExecutionUri} from "../../bos-external-dependency-adapter/scripts/safe-execution-uri.mjs";
import {validateApiContractResponse} from "../../bos-app-discovery/scripts/validate-discovery.mjs";
import {validateCallbackReport,validateCallbackUsage,validateStandingRegistration,validateWorkflowCatalog,validateWorkflowControlResponse,validateWorkflowAction,reviewCallbackGrant} from "./callback-runtime-client.mjs";

const lifecycleVerbs = new Set(["start", "complete", "step", "failed", "state"]);
const journeyStatuses = new Set([
  "not_started",
  "awaiting_client",
  "client_action_required",
  "step_completed",
  "failure_caught",
  "in_progress",
  "completed",
  "failed",
  "expired"
]);
const forbiddenPublicKeys = new Set([
  "journey_id",
  "execution_id",
  "graph_id",
  "snapshot_id",
  "compiled_snapshot",
  "compiled_fingerprint",
  "digest",
  "revision",
  "state_version",
  "node_occurrence",
  "occurrence",
  "idempotency_key",
  "retry_count",
  "retry_state",
  "action_id",
  "artifact_ref",
  "object_name",
  "provider",
  "provider_id",
  "provider_account_id",
  "provider_error",
  "provider_message",
  "provider_payload",
  "provider_response",
  "database_id",
  "sql",
  "stack_trace",
  "attendee",
  "attendees",
  "email",
  "emails",
  "email_address",
  "email_addresses",
  "recipient",
  "recipients",
  "access_token",
  "refresh_token",
  "bearer_token",
  "api_key",
  "credential_id",
  "authority_context",
  "org_id",
  "organization_id",
  "app_code",
  "application_id",
  "installed_app_id",
  "role_id",
  "user_id"
]);
const actionFields = new Set(["verb", "method", "href", "payload_schema"]);
const bosContextHandlePattern = /^bos_ctx_v2_[a-f0-9]{64}$/u;
const bosContextHeader = "X-BOS-Context-Handle";
// Retain the exact serialized submission only for this local request's lifetime.
// It adds no wire field, public locator or persisted execution state.
const registrationSubmissions = new WeakMap();

function requireObject(value, label) {
  if (!value || typeof value !== "object" || Array.isArray(value)) {
    throw new Error(`${label} must be an object`);
  }
  return value;
}

function requireString(value, label) {
  if (typeof value !== "string" || !value.trim()) {
    throw new Error(`${label} must be a non-empty string`);
  }
  return value;
}

function requireSafeString(value, label, maximum) {
  requireString(value, label);
  if (value.length > maximum || /[\r\n\u0000-\u001f\u007f]/u.test(value)) {
    throw new Error(`${label} must be a bounded printable string`);
  }
  return value;
}

function requirePublicErrorMessage(value, label) {
  if (typeof value !== "string" || value.length === 0) {
    throw new Error(`${label} must be a non-empty string`);
  }
  let length = 0;
  for (const _character of value) {
    length += 1;
    if (length > 2048) {
      throw new Error(`${label} must contain at most 2048 Unicode characters`);
    }
  }
  return value;
}

function validatePublicCode(value, label) {
  if (typeof value !== "string" ||
      !/^(?:[a-z][a-z0-9_]{0,127}|[A-Z][A-Z0-9_]{0,127})$/u.test(value)) {
    throw new Error(`${label} must be an exact canonical public code`);
  }
  return value;
}

function validateCorrelationId(value, label) {
  if (typeof value !== "string" ||
      !/^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/u.test(value)) {
    throw new Error(`${label} must be a valid public correlation ID`);
  }
  return value;
}

function requireExactKeys(value, allowed, label) {
  for (const key of Object.keys(value)) {
    if (!allowed.has(key)) throw new Error(`${label} has undeclared field ${key}`);
  }
}

function normalizedSecurityKey(value) {
  return String(value)
    .replace(/([a-z0-9])([A-Z])/g, "$1_$2")
    .replace(/[^A-Za-z0-9]+/g, "_")
    .replace(/^_+|_+$/g, "")
    .toLowerCase();
}

function rejectInternalState(value, path = "journey response") {
  if (!value || typeof value !== "object") return;
  if (Array.isArray(value)) {
    value.forEach((item, index) => rejectInternalState(item, `${path}[${index}]`));
    return;
  }
  for (const [key, child] of Object.entries(value)) {
    if (forbiddenPublicKeys.has(normalizedSecurityKey(key))) {
      throw new Error(`${path}.${key} exposes internal journey state`);
    }
    rejectInternalState(child, `${path}.${key}`);
  }
}

function rejectEnvelopeInternalState(value, publicError, path = "journey response") {
  for (const [key, child] of Object.entries(value)) {
    if (key === "error" && child === publicError) continue;
    if (forbiddenPublicKeys.has(normalizedSecurityKey(key))) {
      throw new Error(`${path}.${key} exposes internal journey state`);
    }
    rejectInternalState(child, `${path}.${key}`);
  }
}

function validateHref(href, label) {
  requireString(href, label);
  return validateSafeBosExecutionUri(href, label);
}

export function validateActionEnvelope(action, { lifecycleOnly = false } = {}) {
  requireObject(action, "action");
  requireExactKeys(action, actionFields, "action");
  for (const field of ["verb", "method", "href"]) {
    requireString(action[field], `action.${field}`);
  }
  if (lifecycleOnly && !lifecycleVerbs.has(action.verb)) {
    throw new Error("action.verb is not a journey lifecycle action");
  }
  if (!new Set(["GET", "POST"]).has(action.method)) {
    throw new Error("action.method must be GET or POST");
  }
  validateHref(action.href, "action.href");
  if (!Object.hasOwn(action, "payload_schema")) {
    throw new Error("action.payload_schema is required");
  }
  if (action.payload_schema !== null) {
    requireObject(action.payload_schema, "action.payload_schema");
  }
  if ((action.method === "GET" || action.verb === "state") && action.payload_schema !== null) {
    throw new Error("bodyless observation actions require payload_schema null");
  }
  if (lifecycleVerbs.has(action.verb)) {
    const expectedMethod = action.verb === "state" ? "GET" : "POST";
    if (action.method !== expectedMethod) {
      throw new Error(`${action.verb} action must use ${expectedMethod}`);
    }
    if (["start", "step", "state"].includes(action.verb) && action.payload_schema !== null) {
      throw new Error(`${action.verb} action must declare no payload schema`);
    }
  }
  return action;
}

function validatePayload(payload, schema) {
  const ajv = new Ajv2020({ allErrors: true, strict: false });
  ajv.addFormat("date-time", {
    type: "string",
    validate: (value) =>
      /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})$/.test(value) &&
      !Number.isNaN(Date.parse(value))
  });
  const validate = ajv.compile(schema);
  if (!validate(payload)) {
    const details = (validate.errors ?? [])
      .map((error) => `${error.instancePath || "$"} ${error.message}`)
      .join("; ");
    throw new Error(`action payload does not match payload_schema: ${details}`);
  }
}

export function buildActionRequest(action, payload) {
  validateActionEnvelope(action);
  const supplied = arguments.length >= 2;
  if (action.payload_schema === null) {
    if (supplied) throw new Error("action without a payload schema must not include a caller payload");
    const emptyJsonPost = action.method === "POST";
    return {
      method: action.method,
      href: action.href,
      headers: emptyJsonPost ? { "content-type": "application/json" } : {},
      body: emptyJsonPost ? "{}" : undefined
    };
  }
  if (!supplied) throw new Error("action requires a body declared by payload_schema");
  validatePayload(payload, action.payload_schema);
  return {
    method: action.method,
    href: action.href,
    headers: { "content-type": "application/json" },
    body: JSON.stringify(payload)
  };
}

function bindIdentityV2Context(request, contextHandle, headerName = bosContextHeader) {
  if (headerName !== bosContextHeader) {
    throw new Error(`context header must be ${bosContextHeader}`);
  }
  requireString(contextHandle, "context_handle");
  if (!bosContextHandlePattern.test(contextHandle)) {
    throw new Error("context_handle must be the current opaque identity-v2 handle");
  }
  return {
    ...request,
    headers: {
      ...request.headers,
      [headerName]: contextHandle
    }
  };
}

export function buildIdentityV2JourneyActionRequest(action, contextHandle, payload) {
  validateActionEnvelope(action, { lifecycleOnly: true });
  const request = arguments.length >= 3
    ? buildActionRequest(action, payload)
    : buildActionRequest(action);
  return bindIdentityV2Context(request, contextHandle);
}

export function buildIdentityV2WorkflowActionRequest(action, contextHandle, payload) {
  validateWorkflowAction(action);
  return bindIdentityV2Context(arguments.length>=3 ? buildActionRequest(action,payload) : buildActionRequest(action),contextHandle);
}

export function buildDiscoveredOperationRequest(contract, contextHandle, payload) {
  requireObject(contract, "operation contract");
  requireString(contract.operation, "operation contract.operation");
  if (contract.status !== "described") {
    throw new Error("operation contract must be described");
  }
  requireObject(contract.execution, "operation contract.execution");
  requireExactKeys(
    contract.execution,
    new Set(["method", "uri", "context_header", "transport"]),
    "operation contract.execution"
  );
  if (contract.execution.transport !== null && contract.execution.transport !== undefined) {
    throw new Error("journey_runtime operations are not direct HTTPS operations");
  }
  validateHref(contract.execution.uri, "operation contract.execution.uri");
  requireObject(contract.input_schema, "operation contract.input_schema");

  const action = {
    verb: "query",
    method: contract.execution.method,
    href: contract.execution.uri,
    payload_schema: contract.input_schema
  };
  const expandedExecution = Object.hasOwn(contract.execution, "context_header") ||
    Object.hasOwn(contract.execution, "transport");
  if (!expandedExecution) {
    return arguments.length >= 2
      ? buildActionRequest(action, contextHandle)
      : buildActionRequest(action);
  }
  const request = arguments.length >= 3
    ? buildActionRequest(action, payload)
    : buildActionRequest(action);
  return bindIdentityV2Context(
    request,
    contextHandle,
    contract.execution.context_header
  );
}

export function buildJourneyRegistrationRequest(contract, contextHandle, document) {
  validateApiContractResponse(contract, {operation:"lead-director.journeys.register"});
  const execution = contract.execution;
  if (execution.method !== "POST" || execution.transport !== "https" ||
      execution.context_header !== bosContextHeader) {
    throw new Error("journey registration must use its discovered HTTPS API v1 route and context header");
  }
  validateHref(execution.uri, "journey registration URI");
  validatePayload(document, contract.input_schema);
  const request=bindIdentityV2Context({
    method: "POST",
    href: execution.uri,
    headers: {"content-type":"application/json"},
    body: JSON.stringify(document)
  }, contextHandle, execution.context_header);
  registrationSubmissions.set(request,request.body);
  return Object.freeze(request);
}

export function validatePublicError(error, label = "error") {
  requireObject(error, label);
  requireExactKeys(
    error,
    new Set(["code", "message", "retryable", "correlation_id", "details"]),
    label
  );
  validatePublicCode(error.code, `${label}.code`);
  requirePublicErrorMessage(error.message, `${label}.message`);
  if (typeof error.retryable !== "boolean") {
    throw new Error(`${label}.retryable must be boolean`);
  }
  validateCorrelationId(error.correlation_id, `${label}.correlation_id`);
  if (!Array.isArray(error.details)) {
    throw new Error(`${label}.details must be an array`);
  }
  error.details.forEach((detail, index) => {
    requireObject(detail, `${label}.details[${index}]`);
    rejectInternalState(detail, `${label}.details[${index}]`);
  });
  return error;
}

export function validateClientInstruction(instruction) {
  requireObject(instruction, "instruction");
  requireString(instruction.goal, "instruction.goal");
  requireString(instruction.message, "instruction.message");
  if (instruction.problem !== undefined) {
    requireObject(instruction.problem, "instruction.problem");
    requireString(instruction.problem.code, "instruction.problem.code");
    requireString(instruction.problem.message, "instruction.problem.message");
  }
  if (instruction.semantic_operation !== undefined) {
    requireString(instruction.semantic_operation, "instruction.semantic_operation");
  }
  if (instruction.approval !== undefined) {
    requireObject(instruction.approval, "instruction.approval");
    if (typeof instruction.approval.required !== "boolean") {
      throw new Error("instruction.approval.required must be boolean");
    }
  }
  if (instruction.after_success !== undefined) {
    validateActionEnvelope(instruction.after_success, { lifecycleOnly: true });
  }
  if (instruction.on_failure !== undefined) {
    validateActionEnvelope(instruction.on_failure, { lifecycleOnly: true });
  }
  rejectInternalState(instruction, "instruction");
  return instruction;
}

export function validateClientResolution(resolution) {
  requireObject(resolution, "resolution");
  requireExactKeys(
    resolution,
    new Set([
      "goal",
      "instruction",
      "operation",
      "requires_user_approval",
      "approval_scope",
      "after_success"
    ]),
    "resolution"
  );
  requireString(resolution.goal, "resolution.goal");
  if (!/^[a-z][a-z0-9_]{0,127}$/u.test(resolution.goal)) {
    throw new Error("resolution.goal must be a published semantic goal");
  }
  requireString(resolution.instruction, "resolution.instruction");
  if (resolution.instruction.length > 4000) {
    throw new Error("resolution.instruction exceeds the published bound");
  }
  if (resolution.operation !== undefined &&
      (typeof resolution.operation !== "string" ||
       resolution.operation.length > 255 ||
       !/^[a-z0-9][a-z0-9_-]*(?:\.[a-z0-9][a-z0-9_-]*)+$/u.test(resolution.operation))) {
    throw new Error("resolution.operation must be a published semantic operation");
  }
  if (typeof resolution.requires_user_approval !== "boolean") {
    throw new Error("resolution.requires_user_approval must be boolean");
  }
  if (resolution.approval_scope !== undefined) {
    if (!Array.isArray(resolution.approval_scope) ||
        resolution.approval_scope.length > 64 ||
        new Set(resolution.approval_scope).size !== resolution.approval_scope.length ||
        resolution.approval_scope.some((item) =>
          typeof item !== "string" || !/^[a-z][a-z0-9_.-]{0,127}$/u.test(item))) {
      throw new Error("resolution.approval_scope is invalid");
    }
  }
  if (resolution.requires_user_approval && !resolution.approval_scope?.length) {
    throw new Error("resolution.approval_scope is required when approval is required");
  }
  validateActionEnvelope(resolution.after_success, { lifecycleOnly: true });
  if (resolution.after_success.verb !== "step" ||
      resolution.after_success.payload_schema !== null) {
    throw new Error("resolution.after_success must be the returned bodyless step action");
  }
  rejectInternalState(resolution, "resolution");
  return resolution;
}

export function validateJourneyEnvelope(body) {
  requireObject(body, "journey response");
  const publicError = body.error === undefined
    ? undefined
    : validatePublicError(body.error);
  rejectEnvelopeInternalState(body, publicError);
  requireString(body.identity, "journey response.identity");
  if (!journeyStatuses.has(body.status)) {
    throw new Error("journey response.status is invalid");
  }
  if (body.current_step !== undefined) {
    requireObject(body.current_step, "journey response.current_step");
    requireString(body.current_step.code, "journey response.current_step.code");
    if (!["client", "server"].includes(body.current_step.type)) {
      throw new Error("journey response.current_step.type must be client or server");
    }
  }
  if (body.status === "awaiting_client") {
    requireObject(body.current_step, "journey response.current_step");
    if (body.current_step.type !== "client") {
      throw new Error("awaiting_client current_step must be client-owned");
    }
    validateClientInstruction(body.instruction);
    requireObject(body.instruction.after_success, "instruction.after_success");
    requireObject(body.instruction.on_failure, "instruction.on_failure");
    validateActionEnvelope(body.instruction.after_success, { lifecycleOnly: true });
    validateActionEnvelope(body.instruction.on_failure, { lifecycleOnly: true });
    if (body.instruction.after_success.verb !== "complete") {
      throw new Error("instruction.after_success must be the returned complete action");
    }
    if (body.instruction.on_failure.verb !== "failed") {
      throw new Error("instruction.on_failure must be the returned failed action");
    }
  }
  if (body.status === "client_action_required") {
    requireObject(body.current_step, "journey response.current_step");
    if (body.current_step.type !== "server") {
      throw new Error("client_action_required current_step must be server-owned");
    }
    requireString(
      body.current_step.operation,
      "journey response.current_step.operation"
    );
    validatePublicError(body.error);
    validateClientResolution(body.resolution);
  }
  if (["not_started", "step_completed", "failure_caught", "in_progress"].includes(body.status)) {
    validateActionEnvelope(body.action, { lifecycleOnly: true });
  }
  if (body.status === "not_started" && body.action.verb !== "start") {
    throw new Error("not_started must return the start action");
  }
  if (["step_completed", "failure_caught"].includes(body.status) && body.action.verb !== "step") {
    throw new Error(`${body.status} must return the step action`);
  }
  if (body.status === "in_progress") {
    if (body.registration !== undefined) {
      validateStandingRegistration(body.registration);
      if (body.current_node !== undefined || body.action.verb!=="state" || !Number.isInteger(body.retry_after_seconds) || body.retry_after_seconds<1 || body.retry_after_seconds>900) throw new Error("standing registration lifecycle is invalid");
      return body;
    }
    requireObject(body.current_node, "journey response.current_node");
    requireString(body.current_node.code, "journey response.current_node.code");
    if (body.current_node.type !== "server") {
      throw new Error("in_progress current_node must be server-owned");
    }
    requireString(body.current_node.operation, "journey response.current_node.operation");
    if (!Number.isInteger(body.retry_after_seconds) || body.retry_after_seconds < 0) {
      throw new Error("in_progress retry_after_seconds must be a non-negative integer");
    }
    if (body.action.verb !== "state" || body.action.method !== "GET") {
      throw new Error("in_progress must return a bodyless state GET action");
    }
  }
  if (["completed", "failed", "expired"].includes(body.status)) {
    if (Object.hasOwn(body, "action")) {
      throw new Error("terminal journey response must not return an action");
    }
    if (Object.hasOwn(body, "instruction") || Object.hasOwn(body, "resolution")) {
      throw new Error("terminal journey response must not return a continuation instruction");
    }
  }
  if (body.status === "completed") {
    requireObject(body.outcome, "completed journey response.outcome");
    if (Object.hasOwn(body, "error")) {
      throw new Error("completed journey response must not return an error");
    }
  }
  if (["failed", "expired"].includes(body.status) && !Object.hasOwn(body, "error")) {
    throw new Error(`${body.status} journey response requires an error`);
  }
  if (body.error !== undefined) validatePublicError(body.error);
  return body;
}

export function validateRegistrationResponse(body) {
  requireObject(body, "registration response");
  if (typeof body.compiled !== "boolean") {
    throw new Error("registration response.compiled must be boolean");
  }
  if (body.compiled) {
    rejectInternalState(body, "registration response");
    requireExactKeys(body, new Set(["compiled", "identity", "actions", "callback_report"]), "registration response");
    if (body.callback_report!==undefined) validateCallbackReport(body.callback_report);
    requireString(body.identity, "registration response.identity");
    requireObject(body.actions, "registration response.actions");
    requireExactKeys(body.actions, new Set(["start"]), "registration response.actions");
    validateActionEnvelope(body.actions.start, { lifecycleOnly: true });
    if (body.actions.start.verb !== "start" || body.actions.start.method !== "POST" ||
        body.actions.start.payload_schema !== null) {
      throw new Error("compiled registration must return a bodyless start action");
    }
    return body;
  }
  const publicError = validatePublicError(body.error, "registration response.error");
  rejectEnvelopeInternalState(body, publicError, "registration response");
  if (!Array.isArray(body.errors) || body.errors.length === 0) {
    throw new Error("compile failure requires actionable compiler errors");
  }
  for (const [index, error] of body.errors.entries()) {
    requireObject(error, `registration response.errors[${index}]`);
    validatePublicCode(error.code, `registration response.errors[${index}].code`);
    requireString(error.path, `registration response.errors[${index}].path`);
    requireSafeString(error.message, `registration response.errors[${index}].message`, 2048);
  }
  if (Object.hasOwn(body, "action") || Object.hasOwn(body, "actions")) {
    throw new Error("compile failure must not return an action");
  }
  return body;
}

function headerValue(headers, name) {
  if (!headers || typeof headers !== "object") return undefined;
  const entry = Object.entries(headers).find(([key]) => key.toLowerCase() === name);
  return entry?.[1];
}

export function interpretJourneyResponse(response, {registrationRequest} = {}) {
  requireObject(response, "HTTP response");
  if (!Number.isInteger(response.http_status)) {
    throw new Error("HTTP response.http_status must be an integer");
  }
  requireObject(response.body, "HTTP response.body");
  const publicError = response.body.error === undefined
    ? undefined
    : validatePublicError(response.body.error);
  rejectEnvelopeInternalState(response.body, publicError);
  if (Object.hasOwn(response.body,"workflows")) {
    if(response.http_status<200||response.http_status>299) throw new Error("workflow catalog requires a successful HTTP status");
    return {next:"workflow_catalog",body:validateWorkflowCatalog(response.body)};
  }
  if (Object.hasOwn(response.body,"workflow_ref")) {
    if(response.http_status<200||response.http_status>299) throw new Error("workflow control response requires a successful HTTP status");
    const workflow=validateWorkflowControlResponse(response.body);
    if(Object.keys(workflow.lifecycle).length===2) return {next:"workflow_view",body:workflow};
    return {...interpretJourneyResponse({...response,body:workflow.lifecycle}),workflow};
  }
  const errorCode = publicError?.code?.toUpperCase();
  // Callback errors also occur inside ordinary failed/failure-caught lifecycle
  // envelopes. Their status, terminal rules and actions use the same validator
  // as every other lifecycle response below.
  if (errorCode?.startsWith("CALLBACK_") && !Object.hasOwn(response.body, "status")) {
    if (response.http_status < 400 || response.http_status > 599) throw new Error("callback errors require an HTTP error status");
    const usage = response.body.usage === undefined ? undefined : validateCallbackUsage(response.body.usage);
    if (errorCode === "CALLBACK_LIMIT_REACHED" && usage === undefined && response.http_status !== 409) {
      throw new Error("callback quota errors require current usage and limits");
    }
    if (usage === undefined && Object.hasOwn(response.body,"usage")) throw new Error("callback usage is invalid");
    return {next:"callback_error",error:publicError,...(usage === undefined ? {} : {usage})};
  }
  if (errorCode === "WORKFLOW_OPERATION_EXPIRED") return {next:"refresh_workflow",error:publicError};

  if (errorCode === "JOURNEY_CREATION_RATE_LIMITED") {
    const seconds = response.body.retry_after_seconds;
    if (!Number.isInteger(seconds) || seconds < 1) {
      throw new Error("creation rate limit requires retry_after_seconds");
    }
    const retryAfter = Number(headerValue(response.headers, "retry-after"));
    if (!Number.isInteger(retryAfter) || retryAfter !== seconds) {
      throw new Error("Retry-After must equal retry_after_seconds");
    }
    return {
      next: "await_explicit_user_request",
      retry_after_seconds: seconds,
      error: publicError
    };
  }
  if (errorCode === "JOURNEY_ACTIVE_LIMIT_REACHED") {
    const resolution = requireObject(response.body.resolution, "active capacity resolution");
    requireExactKeys(
      resolution,
      new Set(["goal", "instruction", "stoppable_journeys"]),
      "active capacity resolution"
    );
    if (resolution.goal !== "free_journey_capacity") {
      throw new Error("active capacity resolution goal is invalid");
    }
    requireString(resolution.instruction, "active capacity resolution.instruction");
    if (!Array.isArray(resolution.stoppable_journeys)) {
      throw new Error("active capacity response requires stoppable_journeys");
    }
    for (const [index, journey] of resolution.stoppable_journeys.entries()) {
      requireObject(journey, `stoppable_journeys[${index}]`);
      requireString(journey.identity, `stoppable_journeys[${index}].identity`);
      requireString(journey.name, `stoppable_journeys[${index}].name`);
      if (journey.expires_at !== null) {
        requireString(journey.expires_at, `stoppable_journeys[${index}].expires_at`);
      }
      validateActionEnvelope(journey.action, { lifecycleOnly: true });
      if (journey.action.verb !== "state") {
        throw new Error("stoppable journey must return its exact state action");
      }
    }
    return {
      next: resolution.stoppable_journeys.length
        ? "request_stop_selection"
        : "capacity_unavailable",
      choices: resolution.stoppable_journeys,
      error: publicError
    };
  }
  if (response.http_status === 404 && errorCode === "JOURNEY_NOT_FOUND") {
    return { next: "terminal_not_found", error: publicError };
  }

  if (Object.hasOwn(response.body, "compiled")) {
    const registration = validateRegistrationResponse(response.body);
    if (registration.compiled) {
      if (response.http_status < 200 || response.http_status > 299) {
        throw new Error("compiled registration requires a successful HTTP status");
      }
      let submitted;
      if(registrationRequest!==undefined) {
        const serialized=registrationSubmissions.get(registrationRequest);
        if(serialized===undefined || registrationRequest.body!==serialized) throw new Error("Registration review requires the unchanged original builder request.");
        submitted=JSON.parse(serialized);
        if(registration.identity!==submitted.identity) throw new Error("Registration response identity differs from the submitted document.");
        if(submitted.bootstrap?.callbacks?.length && registration.callback_report===undefined) throw new Error("Callback submission requires its callback grant report before Start.");
      }
      if(registration.callback_report!==undefined) {
        if(submitted===undefined) throw new Error("Callback registration review requires its original builder request.");
        const presentation=reviewCallbackGrant(submitted,registration.callback_report);
        return {next:"review_callback_grant",identity:registration.identity,callback_report:registration.callback_report,
          presentation,action:registration.actions.start};
      }
      return { next: "invoke_action", action: registration.actions.start };
    }
    return { next: "correct_bosl", error: registration.error, errors: registration.errors };
  }

  const body = validateJourneyEnvelope(response.body);
  switch (body.status) {
    case "not_started":
      return { next: "invoke_action", action: body.action };
    case "awaiting_client":
      return { next: "client_instruction", instruction: body.instruction };
    case "client_action_required":
      return {
        next: "resolve_instruction",
        error: body.error,
        resolution: body.resolution
      };
    case "step_completed":
    case "failure_caught":
      return { next: "invoke_action", action: body.action };
    case "in_progress":
      if(body.registration!==undefined) return {next:"standing_workflow",registration:body.registration,action:body.action};
      return {
        next: "poll_state",
        retry_after_seconds: body.retry_after_seconds,
        action: body.action
      };
    case "completed":
    case "failed":
    case "expired":
      return { next: "terminal", body };
    default:
      throw new Error("unsupported journey response state");
  }
}

export async function runJourneyRecovery(
  initialResponse,
  { wait, invoke, contextHandle } = {}
) {
  if (typeof wait !== "function" || typeof invoke !== "function") {
    throw new Error("runJourneyRecovery requires wait and invoke functions");
  }
  let response = initialResponse;
  while (true) {
    const decision = interpretJourneyResponse(response);
    if (decision.next !== "poll_state") return response;
    await wait(decision.retry_after_seconds);
    const request = contextHandle === undefined
      ? buildActionRequest(decision.action)
      : buildIdentityV2JourneyActionRequest(decision.action, contextHandle);
    response = await invoke(request);
  }
}
