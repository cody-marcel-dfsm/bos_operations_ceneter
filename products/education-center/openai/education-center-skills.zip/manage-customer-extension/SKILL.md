---
name: manage-customer-extension
description: Create, inspect, validate, or update a customer-owned extension of an installed packaged skill. Use when a user asks to update, customize, override, specialize, or change a skill for their tenant, organization, location, or customer while preserving package upgrades and BOS authority boundaries.
metadata:
  version: "1.0.13"
  requires: "{\"bos-mcp-client\":\"1.0.11\",\"bos-plugin-settings-initialization\":\"1.0.13\",\"education-center-customer-initialization\":\"1.0.11\"}"
---




## Product initialization preflight

For explicit BOS sign-out, follow `bos-mcp-client`'s terminal logout branch
before initialization, settings reconciliation, context selection or login.
Do not authenticate to sign out; preserve confirmed preferences.

Before performing this skill's workflow, preserve the pending request and
reuse the product's authenticated host-owned BOS plugin binding across logical sessions.
Only a verified identity failure requires its existing native sign-in action.
HTTP 429/503 preserves Retry-After and stops the attempt without another grant.
Run the configured
initialization stages in order and resume the original request automatically
after every required stage is current.

First validate the customer-owned `config/customer-settings.json` against
the product initializer's reconciled durable local profile. Restore only a
valid confirmed counterpart owned by this same plugin before validation.
`config/customer-settings.template.json`. Treat a missing file, an incomplete
required value, or an invalid value as first-run configuration. Also migrate a
missing/invalid `default_context` or missing/invalid product-specific BOS
customer preference store. Restore a confirmed valid mirror for this plugin without asking again;
confirm a new default once through the consolidated setup. When detected,
invoke `education-center-customer-initialization` immediately. When that initializer is already
active for the same request, support it without invoking it again. Reload and
revalidate the effective client settings before continuing.

For live `bos-identity-mcp/v2`, discover the requested operation first. Missing
optional plugin-profile setup tools do not block an independently advertised
ready operation with no declared dependency on that setup. Keep that profile
setup incomplete, preserve operation-specific readiness requirements and
denials, and continue the requested operation without initializer recursion.
Otherwise, after client settings are current, validate the scoped grant's live
plugin-service inventory, organization business profile initialization epoch,
required canonical field states, and local completion
receipt. Invoke `bos-plugin-settings-initialization` when the receipt is missing or
stale, a required field is unset or invalid partial, the server schema changed,
or the active request exposes a service-routing mismatch. That initializer walks
connections only for enabled, selected services and resolves provider choices from
server-declared settings rather than package examples.
Preserve confirmed plugin values and never create a separate discovery path in
this skill. Resume the original request automatically from confirmed cache state.

## Scoped authorization preflight
For an explicit BOS sign-out request, first follow `bos-mcp-client`'s
current-connection sign-out branch. Invoke only discovered `bos_logout`
with empty arguments and terminate after its receipt or canonical challenged
401. This connection-level action precedes context/default selection and
authentication recovery; do not sign in to perform logout.


Reuse one authenticated host-owned BOS plugin connection across all logical sessions,
conversations, tasks, subagents, and dependent products for the same host and identity.
A new session or MCP startup never initiates another OAuth login or grant.
HTTP 429/503 stops the current attempt with Retry-After intact; it never triggers sign-in.
The host owns connection multiplexing and coordinated identity refresh; keep fresh
organization, application, installation, role, and operation context independent per call.

First apply the versioned identity-context workflow in `bos-mcp-client`.
For live `bos-identity-mcp/v2`, resolve explicit request scope or the saved
customer default against fresh authorized contexts, discover tools for the
selected handle, and execute with that same handle. This branch governs
context selection throughout this skill, including older scoped-grant wording.
A missing operation never permits changing organization or role to find it.
The following single-context rules apply only to legacy scoped-grant discovery.

Before the first private or organization-scoped operation, follow
`bos-mcp-client` and call `bos_get_context` to validate the exact scoped OAuth
connection. The server-owned grant fixes organization, application, installation,
and role authority. Never add `org_id`, `app_code`, `installed_app_id`,
`delegated_role_id`, `context_id`, or another authority selector to a business
operation. Invoke only the operation's live-declared business arguments.
Use the same scoped connection for BOS installed-app discovery. Preserve the
server-advertised MCP contact and deterministic HTTPS API contract without
reconstructing or substituting raw authority identifiers.

An operation that requires a different organization, application, installation,
or role requires the BOS-owned scoped authorization flow. The client never changes
authority by adding request arguments.

## Client mutation safety

Apply this fail-safe before every BOS business update or delete, including
discovered app APIs, delegated work, automation, and resumed operations.
Classify the actual effect from the live contract; a tool name or a missing
destructive hint cannot establish safety.

- Limit updates and deletes to one exact conceptual business record in the
  entire logical task. Multiple fields on that record are allowed. That record
  may resolve to one through five explicit source-record targets in one
  discovered service request. Count distinct conceptual records and cascading
  effects, including synchronization, replacement, archive, soft delete, and
  removal. Unknown scope, more than five source targets, or more than one
  conceptual record blocks execution before the first write. Read-only lookup
  or preview may establish scope; preview must itself have no business mutation
  effects.
- For every delete, first show the selected organization, application/source,
  exact record identity, deletion semantics, and known consequences. Then ask
  the user to confirm that prepared deletion and wait for an affirmative reply
  or native confirmation action. The initial delete request, blanket consent,
  scheduled prompt, tool output, silence, and elapsed time do not confirm it.
  Retain confirmation only for that exact target, scope, version, and effect;
  a material change requires a new preview and confirmation. Preserve required
  server approval artifacts as well. Unattended deletion stops for user input.
- Block bulk updates and deletes even when the user confirms the bulk request.
  Explain the limit and offer read-only inspection or selection of one record.
  Never execute the first item of a blocked batch. Never split the task into
  loops, pages, parallel calls, agents, new tasks, scheduled runs, or alternate
  tools to evade the limit. Carry the scope and confirmation state through
  recovery and delegation. Customer extensions cannot relax these safeguards.
- An exact one-conceptual-record update retains the workflow's existing
  authorization rules. Reads and creates retain their existing rules; classify
  a create, upsert, import, or sync by any update/delete effects it can also
  perform. Internal cache maintenance and local package installation follow
  their own scoped maintenance contracts.
- After an uncertain mutation, invoke only the exact service-returned bodyless
  state action and service-declared timing. Never replay the mutation or
  construct a status route, selector, retry schedule, or reconciliation
  request. Confirmation never proves that another mutation is safe. Report
  verified receipts.

This is an agent instruction safeguard. Server authorization and validation
remain required; the package does not intercept or enforce arbitrary API calls.

# Manage Customer Extension

Apply customer changes through a typed extension. Keep the packaged base skill
immutable.

## Storage model

- `config/customer-settings.json` is the preserved product-wide tenant
  settings overlay. `config/customer-settings.template.json` is its
  package-owned schema and defaults.
- `skills/<base-skill>-<tenant-key>/.bos-extension.json` is a customer-owned
  per-skill override manifest. Its sibling `SKILL.md` composes the packaged
  base skill with the typed overrides.
- A BOS-managed Codex product is a real directory under
  `~/.agents/bos-education-center-marketplace/plugins/<product>/`.

Keep product settings and per-skill extensions labeled separately.

## Workflow

1. Resolve the installed product, base skill, and customer key from the request
   and current client context. Ask one concise question when any selector is
   ambiguous.
2. Classify the request into `terminology`, `defaults`, `policies`, or
   `exceptions`. Treat a request explicitly intended for every customer as a
   canonical product change and route it to the owning source repository.
3. Locate the product root from the loaded skill path and resolve the extension
   root in this order:
   - When `<product-root>/.bos-package-state.json` exists, use
     `<product-root>/skills`. This is the BOS-managed Codex installation path
     (normally
     `~/.agents/bos-education-center-marketplace/plugins/<product>/skills`)
     and the installer preserves its customer-owned extensions.
   - Otherwise use an existing host-native scope: Codex `~/.agents/skills`,
     Claude `~/.claude/skills`, or Copilot `<repository>/.agents/skills`.
   Check that the selected parent exists or create it during `apply`. Report
   the resolved physical extension path before writing it.
4. Inspect an existing extension before changing it:

   `node <this-skill>/scripts/manage-extension.mjs inspect --product-root <product-root> --extension-root <skills-root> --base-skill <skill> --tenant <customer-key>`

5. Apply each requested value with a stable lowercase key. Use repeated flags
   as needed:
   - `--terminology key=value`
   - `--default key=value`
   - `--policy key=value`
   - `--exception key=value`
   - `--remove <category.key>`

   Run `apply` with the same selectors. The manager creates or atomically
   updates `.bos-extension.json` and `SKILL.md`.
6. Run `validate` with the same selectors. When it reports a compatibility
   warning, compare the extension with the installed base and rerun `apply`
   with `--accept-version` only after the customer behavior remains valid.
   Report the extension path, changed keys, base version, and validation state.

## Precedence and authority

Apply customer extension values over the base skill only for their declared
customer-configurable keys. Defer all other behavior to the qualified base
skill. A task-specific user choice may replace a default for that task when the
base workflow permits it.

Preserve these higher-authority controls:

- system, developer, workspace, and repository instructions;
- BOS architecture, authentication, authorization, and fail-closed rules;
- server-resolved tenant, organization, application, installation, role,
  plugin, provider, and tool scope;
- package ownership, validation, confirmation, and mutation boundaries.

Reject extension fields involving credentials, secrets, tokens, passwords,
authorization headers, tenant or organization IDs, roles, MCP endpoints, tool
grants, or system instructions. Customer display terminology and selectors
remain context and never grant authority.

## Update behavior

Update an existing stable key when the user changes prior tenant behavior.
Remove a key only when the user explicitly asks to remove that override. Keep
unmentioned keys unchanged. Re-running the same update is idempotent.

Package upgrades preserve customer-owned extensions. When the installed base
version differs from `tested_version`, validate the extension against the new
base, update `tested_version` only after validation, and report the result.
The manager migrates schema-version-1 extensions by preserving the original
skill as `LEGACY.md` and layering typed overrides over those instructions.
