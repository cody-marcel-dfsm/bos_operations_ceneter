---
name: education-center-student-operations
description: Handle Education Center student enrollment and progress-report workflows across tenant-scoped BOS data and Care.com confirmation emails in the configured customer mailbox. Use when asked to find students, produce or reconcile enrollment reports, compare Lead Director and Calimatic state, include Care.com Backup Care enrollments, locate progress reports, summarize progress evidence, or identify missing student-data capabilities.
metadata:
  version: "1.0.7"
  requires: "{\"bos-mcp-client\":\"1.0.7\",\"bos-plugin-settings-initialization\":\"1.0.7\",\"education-center-customer-initialization\":\"1.0.7\",\"education-center-service-routing\":\"1.0.7\"}"
---




## Product initialization preflight

For explicit BOS sign-out, follow `bos-mcp-client`'s terminal logout branch
before initialization, settings reconciliation, context selection or login.
Do not authenticate to sign out; preserve confirmed preferences.

Before performing this skill's workflow, preserve the pending request and
complete the product's host-managed BOS authentication. Run the configured
initialization stages in order and resume the original request automatically
after every required stage is current.

First validate the customer-owned `config/customer-settings.json` against
the product initializer's reconciled durable local profile. Restore only a
valid confirmed counterpart owned by this same plugin before validation.
`config/customer-settings.template.json`. Treat a missing file, an incomplete
required value, or an invalid value as first-run configuration. Also migrate a
missing/invalid `default_context` or missing/invalid product-specific BOS
customer preference store. Restore a confirmed valid mirror for this plugin without asking again;
confirm a new default once through the consolidated setup. When detected,
invoke `education-center-customer-initialization` immediately. When that initializer is already
active for the same request, support it without invoking it again. Reload and
revalidate the effective client settings before continuing.

For live `bos-identity-mcp/v2`, discover the requested operation first. Missing
optional plugin-profile setup tools do not block an independently advertised
ready operation with no declared dependency on that setup. Keep that profile
setup incomplete, preserve operation-specific readiness requirements and
denials, and continue the requested operation without initializer recursion.
Otherwise, after client settings are current, validate the scoped grant's live
plugin-service inventory, organization business profile initialization epoch,
required canonical field states, and local completion
receipt. Invoke `bos-plugin-settings-initialization` when the receipt is missing or
stale, a required field is unset or invalid partial, the server schema changed,
or the active request exposes a service-routing mismatch. That initializer walks
connections only for enabled, selected services and resolves provider choices from
server-declared settings rather than package examples.
Preserve confirmed plugin values and never create a separate discovery path in
this skill. Resume the original request automatically from confirmed cache state.

## Scoped authorization preflight
For an explicit BOS sign-out request, first follow `bos-mcp-client`'s
current-connection sign-out branch. Invoke only discovered `bos_logout`
with empty arguments and terminate after its receipt or canonical challenged
401. This connection-level action precedes context/default selection and
authentication recovery; do not sign in to perform logout.


First apply the versioned identity-context workflow in `bos-mcp-client`.
For live `bos-identity-mcp/v2`, resolve explicit request scope or the saved
customer default against fresh authorized contexts, discover tools for the
selected handle, and execute with that same handle. This branch governs
context selection throughout this skill, including older scoped-grant wording.
A missing operation never permits changing organization or role to find it.
The following single-context rules apply only to legacy scoped-grant discovery.

Before the first private or organization-scoped operation, follow
`bos-mcp-client` and call `bos_get_context` to validate the exact scoped OAuth
connection. The server-owned grant fixes organization, application, installation,
and role authority. Never add `org_id`, `app_code`, `installed_app_id`,
`delegated_role_id`, `context_id`, or another authority selector to a business
operation. Invoke only the operation's live-declared business arguments.
Use the same scoped connection for BOS installed-app discovery. Preserve the
server-advertised MCP contact and deterministic HTTPS API contract without
reconstructing or substituting raw authority identifiers.

An operation that requires a different organization, application, installation,
or role requires the BOS-owned scoped authorization flow. The client never changes
authority by adding request arguments.

## Client mutation safety

Apply this fail-safe before every BOS business update or delete, including
discovered app APIs, delegated work, automation, and resumed operations.
Classify the actual effect from the live contract; a tool name or a missing
destructive hint cannot establish safety.

- Limit updates and deletes to one exact conceptual business record in the
  entire logical task. Multiple fields on that record are allowed. That record
  may resolve to one through five explicit source-record targets in one
  discovered service request. Count distinct conceptual records and cascading
  effects, including synchronization, replacement, archive, soft delete, and
  removal. Unknown scope, more than five source targets, or more than one
  conceptual record blocks execution before the first write. Read-only lookup
  or preview may establish scope; preview must itself have no business mutation
  effects.
- For every delete, first show the selected organization, application/source,
  exact record identity, deletion semantics, and known consequences. Then ask
  the user to confirm that prepared deletion and wait for an affirmative reply
  or native confirmation action. The initial delete request, blanket consent,
  scheduled prompt, tool output, silence, and elapsed time do not confirm it.
  Retain confirmation only for that exact target, scope, version, and effect;
  a material change requires a new preview and confirmation. Preserve required
  server approval artifacts as well. Unattended deletion stops for user input.
- Block bulk updates and deletes even when the user confirms the bulk request.
  Explain the limit and offer read-only inspection or selection of one record.
  Never execute the first item of a blocked batch. Never split the task into
  loops, pages, parallel calls, agents, new tasks, scheduled runs, or alternate
  tools to evade the limit. Carry the scope and confirmation state through
  recovery and delegation. Customer extensions cannot relax these safeguards.
- An exact one-conceptual-record update retains the workflow's existing
  authorization rules. Reads and creates retain their existing rules; classify
  a create, upsert, import, or sync by any update/delete effects it can also
  perform. Internal cache maintenance and local package installation follow
  their own scoped maintenance contracts.
- After an uncertain mutation, invoke only the exact service-returned bodyless
  state action and service-declared timing. Never replay the mutation or
  construct a status route, selector, retry schedule, or reconciliation
  request. Confirmation never proves that another mutation is safe. Report
  verified receipts.

This is an agent instruction safeguard. Server authorization and validation
remain required; the package does not intercept or enforce arbitrary API calls.

# Education Center Student Operations

## Tenant terminology

Load effective customer settings and resolve the brand through
`education-center-service-routing`. Use `brand_display_name`, or the active
skill extension's `terminology.brand_display_name` override, wherever
customer-facing output names the franchise or brand. Keep technical product,
skill, route, server, environment-variable, tool, capability, authorization,
and record identifiers unchanged.

This skill is for authenticated adult school staff performing legitimate
school administration. Students and minors are data subjects, never users or
operators. Retrieve only the minimum student and family fields necessary for
the requested enrollment or progress-report task. Do not publish, bulk export,
or use these records for admissions, disciplinary, eligibility, or other
high-impact decisions.

Use the authenticated BOS MCP connection and follow the `bos-mcp-client`
context workflow. BOS resolves the Education Center subservice for each tool. Preserve
student identity and provider provenance across every source.
Present enrollment cohorts, progress trends, class distribution, and
cross-source reconciliation with source-backed visuals when useful.
Use BOS for every domain whose effective customer route is `bos`. A configured
`connected_gmail` route may supply Care.com correspondence evidence through the
normal Gmail connector and exact customer mailbox; it grants no BOS authority
and cannot perform Education Center mutations.
For a BOS-routed Gmail, Drive, or Calimatic authentication error, follow
`bos-mcp-client` recovery. For `connected_gmail`, use the Gmail connector's
native account recovery for the exact configured mailbox.

## Explicit application scope

When the user explicitly names an application or source, treat that choice as
part of the request and route to that application before applying domain-word
defaults. For example, “in Lead Director” selects Lead Director even when the
request describes a person as a child or student. Use only that application's
currently advertised operations and returned fields. Do not silently switch
to Calimatic or another source. If the named application does not return the
requested record or fact, state that limitation and ask before consulting a
different source. Apply the domain defaults below only when the user has not
specified an application or source.

## Enrollment

- When no source is named, use Calimatic student and enrollment tools as the enrolled-student source.
- Use Lead Director for prospect and lead state.
- Use published `education_center_search_email_evidence` and `education_center_get_email_thread`
  through the same BOS platform connection only as correspondence/source evidence.
- Resolve the packaged settings defaults plus the preserved customer overlay.
  Follow `source_routes.care_com`: use published Education Center email evidence tools for
  `bos`, or use the normal Gmail connector for `connected_gmail`. Select only
  the exact `mailboxes.care_com` account.
- Stop and report configuration required when the selected route is unavailable
  or a connected-Gmail route lacks `mailboxes.care_com`.
- Use a bounded lookback of up to 180 days before the requested period through
  its end for Care.com notices, then retain only child-days whose service date
  falls inside the requested period.
- Dedupe Care.com request and confirmation notices by numeric job ID. Count only
  a confirmation with body status `Confirmed` as active enrollment; keep a
  `New` request as pending. Expand each confirmed service date to one child-day.
- Preserve child, job ID, site, date/time, estimated payment, age, parent,
  comments, and message timestamp. Exclude a child-day only when a later
  message explicitly cancels that job ID/date.
- Reconcile with stable provider IDs first, then normalized name plus another
  strong field. Keep ambiguous matches separate.

## Calimatic-first named-person results

Complete student/family lookup and enrollment-state comparison using the
Education Center plugin's authorized Calimatic and Lead Director capabilities.
For this focused workflow, use `education-center-service-routing` for customer
settings and context only; this section governs named-person results and
completes without a generic CRM journey workflow.

When Calimatic resolves a named-person lookup, preserve the verified student or
family details with provider provenance and source freshness. If the person is
or may be a lead, discover the Lead Director lookup and state-read operations
available to Education Center through the same BOS connection. Use only their
advertised contracts and returned source selectors. Match stable provider IDs
first, then normalized name plus another strong verified field; keep ambiguous
candidates separate and request the minimum disambiguating value. Compare only
verified Calimatic and Lead Director state, identifying each source and any
discrepancy. A Calimatic result never proves Lead Director graph membership.

Return the verified Calimatic result even when no matching Lead Director record
is found or the required state-read capability is unavailable. State the precise
limitation; preserve authorization denials and follow the existing BOS recovery
contract for authentication failures. Never invent Lead Director state or infer
graph membership, transitions, goals, paths, or reachability.

For a person who is or may be a lead, state plainly: "Lead Director graph
matching requires the CRM plugin." Complete this lookup without invoking
another plugin's skills or making graph matching a prerequisite. Broad roster
and enrollment reports retain their requested aggregate scope.

## Progress reports

- Discover the configured progress-report or student-record source.
- Use Drive for report documents and BOS Gmail for correspondence when relevant.
- Never infer academic progress from enrollment, attendance, lead, or email
  state.

## Output

State use case, date range, system of record, matched student records,
discrepancies, evidence, and action required. Exclude unnecessary contact and
opaque student identifiers.
