---
name: crm-customer-journey
description: Discover and show an authorized Lead Director customer's exact installed sales graph, current lead node, transition history, reachable goals, paths, gates, blockers, and available next steps. Use whenever a lead is displayed, including create/update results, duplicate matches, list entries, and any lead or contact detail request, including named-person find/look-up requests, email or phone lookups, a single field, profile, status, sales-flow, enrollment-progress, lifecycle, graph-position, and journey-path question.
---




## Product initialization preflight

Before performing this skill's workflow, preserve the pending request and
complete the product's host-managed BOS authentication. Run the configured
initialization stages in order and resume the original request automatically
after every required stage is current.

First validate the customer-owned `config/customer-settings.json` against
`config/customer-settings.template.json`. Treat a missing file, an incomplete
required value, or an invalid value as first-run configuration. Also migrate a
missing/invalid `default_context` or missing/invalid shared BOS customer
preference store. Restore a confirmed valid mirror without asking again;
confirm a new default once through the consolidated setup. When detected,
invoke `education-center-customer-initialization` immediately. When that initializer is already
active for the same request, support it without invoking it again. Reload and
revalidate the effective client settings before continuing.

For live `bos-identity-mcp/v2`, discover the requested operation first. Missing
optional plugin-profile setup tools do not block an independently advertised
ready operation with no declared dependency on that setup. Keep that profile
setup incomplete, preserve operation-specific readiness requirements and
denials, and continue the requested operation without initializer recursion.
Otherwise, after client settings are current, validate the scoped grant's live
plugin-service inventory, organization business profile initialization epoch,
required canonical field states, and local completion
receipt. Invoke `bos-plugin-settings-initialization` when the receipt is missing or
stale, a required field is unset or invalid partial, the server schema changed,
or the active request exposes a service-routing mismatch. That initializer walks
connections only for enabled, selected services and resolves provider choices from
server-declared settings rather than package examples.
Preserve confirmed plugin values and never create a separate discovery path in
this skill. Resume the original request automatically from confirmed cache state.

## Scoped authorization preflight

First apply the versioned identity-context workflow in `bos-mcp-client`.
For live `bos-identity-mcp/v2`, resolve explicit request scope or the saved
customer default against fresh authorized contexts, discover tools for the
selected handle, and execute with that same handle. This branch governs
context selection throughout this skill, including older scoped-grant wording.
A missing operation never permits changing organization or role to find it.
The following single-context rules apply only to legacy scoped-grant discovery.

Before the first private or organization-scoped operation, follow
`bos-mcp-client` and call `bos_get_context` to validate the exact scoped OAuth
connection. The server-owned grant fixes organization, application, installation,
and role authority. Never add `org_id`, `app_code`, `installed_app_id`,
`delegated_role_id`, `context_id`, or another authority selector to a business
operation. Invoke only the operation's live-declared business arguments.
Use the same scoped connection for BOS installed-app discovery. Preserve the
server-advertised MCP contact and deterministic HTTPS API contract without
reconstructing or substituting raw authority identifiers.

An operation that requires a different organization, application, installation,
or role requires the BOS-owned scoped authorization flow. The client never changes
authority by adding request arguments.

## Client mutation safety

Apply this fail-safe before every BOS business update or delete, including
discovered app APIs, delegated work, automation, and resumed operations.
Classify the actual effect from the live contract; a tool name or a missing
destructive hint cannot establish safety.

- Limit updates and deletes to one exact conceptual business record in the
  entire logical task. Multiple fields on that record are allowed. That record
  may resolve to one through five explicit source-record targets in one
  discovered service request. Count distinct conceptual records and cascading
  effects, including synchronization, replacement, archive, soft delete, and
  removal. Unknown scope, more than five source targets, or more than one
  conceptual record blocks execution before the first write. Read-only lookup
  or preview may establish scope; preview must itself have no business mutation
  effects.
- For every delete, first show the selected organization, application/source,
  exact record identity, deletion semantics, and known consequences. Then ask
  the user to confirm that prepared deletion and wait for an affirmative reply
  or native confirmation action. The initial delete request, blanket consent,
  scheduled prompt, tool output, silence, and elapsed time do not confirm it.
  Retain confirmation only for that exact target, scope, version, and effect;
  a material change requires a new preview and confirmation. Preserve required
  server approval artifacts as well. Unattended deletion stops for user input.
- Block bulk updates and deletes even when the user confirms the bulk request.
  Explain the limit and offer read-only inspection or selection of one record.
  Never execute the first item of a blocked batch. Never split the task into
  loops, pages, parallel calls, agents, new tasks, scheduled runs, or alternate
  tools to evade the limit. Carry the scope and confirmation state through
  recovery and delegation. Customer extensions cannot relax these safeguards.
- An exact one-conceptual-record update retains the workflow's existing
  authorization rules. Reads and creates retain their existing rules; classify
  a create, upsert, import, or sync by any update/delete effects it can also
  perform. Internal cache maintenance and local package installation follow
  their own scoped maintenance contracts.
- After an uncertain mutation, invoke only the exact service-returned bodyless
  state action and service-declared timing. Never replay the mutation or
  construct a status route, selector, retry schedule, or reconciliation
  request. Confirmation never proves that another mutation is safe. Report
  verified receipts.

This is an agent instruction safeguard. Server authorization and validation
remain required; the package does not intercept or enforce arbitrary API calls.

# CRM Customer Journey

Use the active product MCP for routing, application discovery, contract
validation, and deterministic HTTPS invocation. Read [the Lead Director journey
contract](references/journey-graph-contract.md) before discovery or rendering.

This reusable capability ships in Education Center and uses that product's
scoped MCP connection. Any lead or contact detail
request selects this workflow, including a single field such as an email
address, phone number, owner, appointment, or status.
The user does not need to say “journey” or “graph.”

A named-person lookup such as “find this lead,” “look up this contact,” or a
lookup by email, phone, or a current record selector is an individual detail
request. Continue this workflow before presenting its result,
even when the lookup uses a search operation. Determine presentation from user
intent, independently of the tool name or response being an array. A successful
single-person lookup must continue into the graph workflow in the same turn.
Broad filtered lists preserve their filters and pagination and display each
returned lead in the detailed format below. Keep ambiguous matches separate;
show only the graph membership verified for each candidate and disambiguate
before any targeted action.

Start with `bos-mcp-client` live discovery and `bos_get_context` on the original
request. Resolve deferred tools through the host's discovery facility before
reporting them missing. Resume this workflow automatically after recovery.
`bos_get_context` alone does not perform graph discovery. Inspect the active
product connection for advertised graph and read-operation descriptors under
the current scoped grant. Use the
BOS connection scoped to the authorized application for current application discovery, then perform record and
graph reads through its exact advertised deterministic HTTPS APIs.
Follow
[connected graph reads](references/connected-graph-read.md) when that contract
is advertised. Read the directory for evidence still missing. Continue
from each successful read; evaluate app-query and API capabilities only when
their steps are reached. An absent journey tool in the initial catalog supplies
no evidence that BOS resource discovery is unavailable.

## Current-host read execution

Use the current authenticated product MCP to discover capabilities for the
requested operation. After `bos_get_context` validates the connection's exact
scoped grant, resolve a live-discovered read operation whose descriptor
covers the requested data, then invoke its exact advertised HTTPS method, path,
schema, and audience without client-supplied authority fields. Continue from the API evidence. Select the
supported operation from current discovery; do not construct a route or require
a second connection for the selected application.

All supported operations belong to one current operating contract. Discover
semantic operation identities and argument constraints from current validated
MCP descriptors and their linked API contracts; never invent endpoints or
selectors.
Directory or transport limitations remain scoped to that operation. An
access denial never permits switching routes to evade it. Missing or ambiguous
context, revoked grants, and explicit access denials stop the affected operation.
Every operation retains request-time server authorization.

For journey/detail requests, continue from the record read into graph, goal,
and path discovery through live-described read operations. A current-state-only
record result does not complete this sequence. Use `crm-customer-journey` to
resolve the explicit or application-owned goal and obtain the exact node path.
Only after supported discovery and relevant reads are exhausted or a specific
failure prevents them, render the labeled partial journey with verified state,
known goals, and requested details. Identify the failed or unavailable operation
and unattempted dependent reads. This is an incomplete path result, with no
invented transitions, reachability, actions, or completion.
This rule authorizes no mutations, browser fallback, token extraction, or
hardcoded endpoint. A missing per-app host facility alone must not suppress an
independent successful authorized read or its partial graph presentation.

## Every displayed lead uses the detailed format

Apply this format whenever a response displays a lead, regardless of which
operation produced it: lookup, list/search page, create, update, duplicate or
already-existing match, operation failure with a verified existing lead, or
preview/receipt. The user does not need to request details. A success sentence,
receipt, status badge, contact bullets, or table row alone is incomplete.

For each displayed lead, include:

1. Name, organization, verified current state and the operation outcome.
2. Native node graph from current state through intermediate nodes to canonical
   goals, with the preferred positive-goal route bold and green under the route
   ranking rules below. Follow with the same readable text path and relevant
   conditions/eligibility limits.
3. Available verified profile fields: contact details, owner, recorded dates or
   appointments, and relevant history/actions. Keep missing values explicit
   when relevant and never invent details. Keep technical identifiers out of
   the graph; show them in details only when requested or operationally useful.
4. Source observation time and meaningful freshness/evidence limitations.

After a confirmed create or update, use the result if it supplies complete,
current record evidence; otherwise read the exact resulting lead, then obtain
its graph. On a duplicate match, render the verified existing lead this way.
Complete the authorized mutation first; graph retrieval is a post-result read,
not a write prerequisite. A failed graph read preserves the verified mutation
outcome and yields a labeled partial detailed view after bounded recovery.
Never repeat a write to obtain display evidence.

For lists, keep the requested filters/order and pagination; render one detailed
view per displayed lead. Reuse graph topology only across records with matching
validated context/graph binding, retaining each lead's own current state. Use
bounded pages for large results and disclose coverage. Aggregate-only results
that display no individual leads need no per-lead graph. An explicit user format
request, such as an export or compact list, overrides this display default.

For deletion previews, use current verified details before the required
confirmation. After deletion, label the record Deleted and any retained graph
as last-known/historical with its observation time; do not describe the former
current state as active or invent a deleted graph node. A failed create with no
verified persisted lead shows the failure and submitted fields without a
fabricated lead state or graph. Display changes grant no mutation authority.

## Rich record view by default

For any lead or contact detail request, lead with the person's place in the
application-owned graph, then provide the requested fields and relevant profile
facts below the graph. Include verified current position, completed history,
reachable next states, gates or blockers, pending events, and available next
actions with source freshness. Keep contact information outside graph nodes.
Read-only detail requests never authorize executing those actions.

When no goal is requested, resolve the lead's app-returned desired goal, then
an app-declared default goal, then the sole applicable goal from canonical goal
metadata. These are application-owned selections. If several goals remain,
show their exact paths as labeled alternatives without selecting one for the
user. Ask only when a required path input cannot be resolved from the contract.
Never assume enrollment or a positive goal from sales conventions. When the
user supplies a goal, resolve it against the installed Graph and emphasize its
exact path or blocker. An ambiguous explicit goal requires disambiguation.

For both ordinary details and explicit journey requests, show the ordered path
from the current node through every intermediate node to the resolved goal.
Obtain goal metadata before path planning and use only contract-supported inputs.
A current node plus a goal placeholder does not satisfy the path requirement.

Distinguish graph structure, current transition eligibility, and observed lead
history. Missing history, an empty available-actions list, or unverified goal
attainment does not invalidate a verified structural path. Draw known graph
edges and label their gates as satisfied, blocked, or unknown from app evidence;
keep future nodes pending. When only topology is available, a route traced along
its exact directed edges must be labeled **Structural path — eligibility
unverified**. Never infer an edge. Select the highlighted route using the
verified app evidence and ranking rules below. Retain relevant alternative paths
and protect against graph cycles.

Resolve a contact-to-lead or contact-to-graph relationship from current
application evidence. Never assume every contact is a lead or combine ambiguous
matches. Ask for disambiguation only when identity or graph membership requires
it. If no graph membership or current node can be verified, show the requested
verified details and the precise missing graph evidence. If current state is
known but topology is partial, use the partial-evidence presentation below.
An explicit user request for a different format takes precedence.

## Adapt the access pattern

Resolve the requested lead through the least expensive supported read: exact
server-issued selector, name or contact-field search, scoped filter, or a
record selected from a previous current-context result. Reuse verified identity
and graph evidence when its context and version remain valid. Search is needed
only when identity is unresolved; ambiguity stops the affected record.

The sequence below describes evidence dependencies. A single discovered read
may supply record, graph, goal, and path evidence together; do not repeat reads
already satisfied by valid evidence. Use additional supported operations only
for missing evidence. Keep broad list/search requests scoped to their requested
list. A named-person find or lookup is an individual detail request and includes
the goal path even when a search operation resolves the person.
For several requested detail records, use supported batch reads or bounded
pagination and keep each lead's graph membership and path distinct. The diagram
is presentation of read evidence and never authorizes a CRUD mutation.

## Discover and resolve

1. Inspect the BOS connection resource descriptors under the connection's
   exact scoped grant. A matching connected graph resource can satisfy graph
   and goal discovery directly.
2. For evidence not already supplied by a validated connected resource, use
   the current BOS platform connection. Discover the current app
   description, installed graph, canonical goal semantics, lead and journey
   services, installed plugins, external-evidence ownership, and
   machine-readable API contracts. Use returned operation names and endpoints;
   never embed a Lead Director URL or assume literal MCP tool names.
3. Use the discovered lead-search API when the lead is unresolved, or a
   supported exact read for a valid server-issued selector. Ask for one
   disambiguating value when several authorized records remain.
4. Call the discovered lead-journey API for the current graph node, exact
   transition history, pending gates, available actions, observation time, and
   provenance.
5. Obtain canonical goal metadata with discovered `graph.goals.list` semantics
   and apply the goal resolution above. Call the discovered path-planning API
   with read-only `graph.path.plan` semantics for exact paths from the observed
   current node to those goals, including conditional routes and blockers.
   Keep path planning separate from transition execution.
6. When external evidence is necessary, inspect the discovered service owner.
   Use a Lead Director plugin/service API when it is nested under Lead Director.
   Query another product connection only when that product is independently
   installed and its own authenticated discovery identifies the service.

For the per-app execution path, use discovered deterministic HTTPS APIs. Carry
short-lived audience-bound authentication through the host credential boundary.
Supply only contract-declared business arguments and reject stale versions,
cross-grant state, malformed contracts, and typed denials.

Apply evidence-based failure classification at the actual failed step. Report
completed reads, the observed failure or verified absent
host facility, and later unattempted steps. Preserve server error types and the
pending request; a context-only trace never establishes missing app discovery.
Use no browser automation, DOM inspection,
cached selector, raw authority identifier, or hardcoded endpoint. Use the
Current-host read execution rule for authenticated reads.

## Reconcile the answer

Separate and source-attribute these sections:

1. **Graph facts** — exact installed graph identity/version, nodes, transitions,
   gates, goals, entry/exit state, and graph observation epoch.
2. **Lead facts** — resolved lead, current node, transition history, scheduled
   events, available actions, source service, observation time, and freshness.
3. **External evidence** — independently observed enrollment, roster, billing,
   calendar, or provider facts with owning app/service, observation time, and
   freshness.
4. **GPT inference** — conclusions derived from the preceding facts, labeled as
   inference with missing or conflicting evidence stated explicitly.

Use exact graph labels and transitions. A future event with no observed outcome
evidence remains pending and never becomes a terminal negative result. Report
blocked and conditional edges with their app-returned gate conditions and
required evidence. Never invent a generic stage or infer a transition from list
order, prior screenshots, or sales conventions.

## Partial evidence presentation

After the discovery and read sequence has failed to obtain either a verified
structural route or a path result, and authorized reads have verified the
record's current state, render a **Partial journey —
verified milestones only** diagram on the first response. This presentation
uses evidence already obtained through an authorized workflow; it grants no
alternate endpoint or authentication bypass. The Current-host read execution
rule governs authorized reads. Preserve
any typed discovery or provider failure and state which graph evidence is
missing. With no verified current state, report the failure without a fabricated
journey.

Show the verified current state. When the user requests a goal, show it as a
distinct node. Include any verified application-owned goals even when none was
requested; omit a goal placeholder only when no goal can be resolved.
Label an explicit goal **Requested goal — attainment unverified** and an
application-selected goal **Graph goal — attainment unverified** unless attainment
is verified.
Place confirmed dated milestones in their observed chronology; label timeline
links **Recorded chronology**, never as completed graph transitions. Use a
non-directional dotted connector labeled **Progression unverified** between
current state and goal when no path is known. Include a legend that this link
indicates missing evidence and establishes no reachability or eligible next
step. Add no inferred intermediate stages or percentage complete. Keep future
events pending. Put this visual before record details, with source freshness
and limitations immediately below it. Do not wait for the user to ask for a
visual or retry. An optional provider check failing does not erase independent
verified record evidence.

## Render the native graph

Lead with a Mermaid `flowchart LR` built only from the discovered graph and
lead/path API results. Use no local HTML, browser renderer, attachment, or
external visualization service. Keep node labels concise and exclude contact
details, raw record identifiers, private notes, and authority values.

Place the person's verified current node and the resolved goal prominently
in the same diagram. Include every intermediate node on the verified route and show
relevant branches and gates. Completed history requires observed transition
evidence; future or eligible steps remain distinct from completed steps.
If the goal is unreachable, show that goal and the app-returned blocker without
drawing an invented connecting edge. Disambiguate an explicit goal when needed;
for multiple application goals, show the labeled alternatives described above.

Compose a clear visual hierarchy: place verified completed history before the
current node, the remaining exact path across the center, and the goal at the
right. Each state is its own graph node. Keep the primary route visually
prominent, arrange alternatives as secondary branches, and label transitions
with concise app-owned action or gate text. Retain exact state labels; use short
line breaks for status annotations. Keep dates, long evidence, and contact
fields in the supporting details instead of crowding nodes. Use compact legends
and enough whitespace for the route to read at a glance. For wide or branching
graphs, split into labeled goal-path diagrams sharing the same current node;
retain every intermediate state and relevant gate. Use plain Mermaid syntax
supported by the host and an immediate readable text path.

A known structural transition is drawn even when eligibility is unknown; label
it accordingly. Use dashed edges for conditional or blocked transitions only
when those edges exist in the Graph. An unknown connection remains the explicit
partial-evidence connector. Visual styling must never imply that a pending
transition has happened. Do not classify a known later node as completed from
its position in the diagram.

### Highlight the route to the positive goal

Make the preferred current-to-positive-goal route stand out with thick dark-green
arrows (`#15803D`, `stroke-width:4px`) and bold route labels. Use the app's
recommended/optimal path and its declared objective when supplied. Otherwise,
compute the fewest-transition path over the verified directed topology to the
resolved canonical positive goal and label it **Shortest structural path —
eligibility unverified**. This is a presentation ranking, not permission to
execute a transition or evidence that it is the fastest or highest-converting
business route. Preserve known conditions and blockers; never highlight a known
blocked path as actionable. If no feasible path can be verified, label the
highlighted structural candidate's blocking/unknown gates explicitly.

For tied shortest paths, highlight the tied routes and identify the tie; never
invent a preference. With multiple unresolved positive goals, keep labeled goal
alternatives and rank paths separately. An explicitly requested non-positive
goal keeps the user's requested emphasis. If no positive goal/path exists, show
the supported graph and explain the missing route without fabricating one.

Style every edge of the selected route, every intermediate route node, and its
positive goal consistently. Use pale-green fill `#DCFCE7`, dark text `#14532D`,
green border and `font-weight:bold` for pending route nodes and the positive
goal. Preserve the current node's navy fill/white text and add a thick green
border plus bold text. Retain completed/blocked status styling and its explicit
labels when it conflicts with route fill. Keep alternative edges thin gray and
negative goals visually secondary. Include a compact legend for the green route;
green indicates route emphasis, never completion or eligibility.

For Mermaid, declare each edge separately and use zero-based `linkStyle` indices
for exactly the highlighted edges in final declaration order, for example
`linkStyle 0,2 stroke:#15803D,stroke-width:4px,color:#14532D,font-weight:bold`.
Apply matching node `style`/`classDef` declarations; styling only the destination
node or bolding the prose does not highlight a path. Preserve conditional dashed
edges even when they belong to the highlighted route. Recompute link indices
after any edge insertion/reordering and check that no unrelated edge is green.
Bold the same preferred route in the immediate text-path fallback.

Apply direct text labels plus these high-contrast status styles:

- completed: teal fill `#007A5E`, white text, label `✓ Completed`;
- current: navy fill `#005A9C`, white text, thick border, label `● Current`;
- reachable next: dark gold fill `#9A6700`, white text, label `→ Next`;
- blocked: vermillion fill `#C43B00`, white text, label `! Blocked`;
- later or alternate: light-gray fill `#E5E7EB`, charcoal text, label `Later`;
- goal outside the highlighted route: purple border `#6F42C1` plus its canonical positive, negative, neutral,
  or non-terminal goal class.

Annotate the current node, completed transition history, every reachable goal
path, eligible next edges, gates, blockers, and available next steps on the
graph itself. The graph itself must identify the current position, next states,
blockers, and desired goal when one was requested. Immediately follow with the
same exact route as a plain-text path for a host that does not render Mermaid.

Below the graph, give concise source/version/freshness details and the four
evidence sections. Never execute a transition from this read-only workflow.

## Final response check

Before sending any response that displays a lead, verify that each lead view
contains the detailed format above, including the Mermaid graph and profile details. Known topology
requires the exact current-to-goal route. If a specific discovery/read failure
prevents that route, include the partial-evidence graph of the verified current
state and a precise limitation. A successful record read plus unavailable
topology never justifies omitting the graph. With no verified current state,
state the missing evidence without inventing a node. An explicit user format
instruction retains precedence. A tool result, commentary promise, status bullet,
or plain-text path alone does not satisfy the default graph presentation.
